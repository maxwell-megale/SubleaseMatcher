import { Badge } from "@/components/ui/default/badge";

export default function BadgeDemo() {
  return <Badge>Badge</Badge>;
}
