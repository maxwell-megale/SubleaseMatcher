import { Input } from "@/components/ui/default/input";

export default function InputDemo() {
  return <Input type="email" placeholder="Email" />;
}
