import { Textarea } from "@/components/ui/default/textarea";

export default function TextareaDemo() {
  return <Textarea placeholder="Type your message here." />;
}
