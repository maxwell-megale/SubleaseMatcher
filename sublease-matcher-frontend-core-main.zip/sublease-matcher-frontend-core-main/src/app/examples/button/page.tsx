import { Button } from "@/components/ui/default/button";

export default function ButtonDemo() {
  return <Button>Button</Button>;
}
