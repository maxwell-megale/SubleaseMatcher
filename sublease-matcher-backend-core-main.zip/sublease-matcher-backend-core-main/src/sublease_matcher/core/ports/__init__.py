"""Abstract ports defining repository and service contracts."""
