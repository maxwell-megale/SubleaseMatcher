"""FastAPI dependency wiring."""

from .settings import get_settings

__all__ = ["get_settings"]
