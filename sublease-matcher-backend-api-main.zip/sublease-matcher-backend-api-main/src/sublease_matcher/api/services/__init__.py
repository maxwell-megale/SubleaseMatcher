"""Service coordination layer."""
